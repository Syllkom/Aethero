// ./plugins/search/wikipedia.plugin.js
import { Canvas, Path2D } from '@napi-rs/canvas'

let cachedWikiLogo = null

async function getWikiLogoBuffer() {
    if (cachedWikiLogo) return cachedWikiLogo

    const canvas = new Canvas(400, 400)
    const ctx = canvas.getContext('2d')

    ctx.fillStyle = '#ffffff'
    ctx.fillRect(0, 0, 400, 400)

    ctx.save()
    ctx.translate(40, 40)
    ctx.scale(320 / 640, 320 / 640)
    ctx.fillStyle = '#000000'
    
    const wPath = new Path2D('M639.976 124.005c0 2.244-.72 4.37-2.114 6.343-1.394 1.842-2.977 2.846-4.772 2.846-14.09 1.394-25.607 5.906-34.489 13.512-9 7.606-18.142 22.382-27.602 43.914l-145.254 327.5c-.98 3.118-3.638 4.512-8.02 4.512-3.366 0-6.036-1.524-8.008-4.512l-81.473-170.282-93.722 170.282c-1.972 3.118-4.512 4.512-8.02 4.512-4.228 0-6.886-1.524-8.28-4.512L75.64 190.762c-8.87-20.268-18.284-34.5-28.158-42.52-9.863-8.02-23.634-13.11-41.257-14.918-1.535 0-2.976-.85-4.24-2.374-1.394-1.535-1.972-3.378-1.972-5.504 0-5.362 1.535-8.02 4.512-8.02 12.65 0 26.02.58 40.004 1.725 12.969 1.122 25.04 1.724 36.426 1.724 11.516 0 25.358-.578 41.126-1.724 16.477-1.122 31.11-1.725 43.914-1.725 3.106 0 4.512 2.658 4.512 8.02 0 5.363-.992 7.878-2.847 7.878-12.65.992-22.795 4.24-30.13 9.745-7.335 5.492-10.996 12.65-10.996 21.661 0 4.512 1.535 10.264 4.512 17.032L248.86 447.998l66.957-126.368-62.327-130.738c-11.256-23.363-20.41-38.41-27.568-45.166-7.145-6.756-18.142-10.866-32.764-12.402-1.393 0-2.527-.85-3.78-2.374-1.263-1.535-1.842-3.378-1.842-5.504 0-5.362 1.264-8.02 3.969-8.02 12.638 0 24.343.58 35.02 1.725 10.264 1.122 21.118 1.724 32.788 1.724 11.386 0 23.362-.578 36.165-1.724 13.11-1.122 26.032-1.725 38.694-1.725 3.106 0 4.512 2.658 4.512 8.02 0 5.363-.85 7.878-2.847 7.878-25.5 1.725-38.15 9.012-38.15 21.674 0 5.634 2.988 14.504 8.87 26.48l41.268 83.73 41.068-76.56c5.634-10.855 8.598-19.996 8.598-27.284 0-17.48-12.65-26.752-38.15-27.886-2.244 0-3.366-2.646-3.366-7.878 0-1.973.543-3.638 1.665-5.363 1.123-1.712 2.245-2.515 3.367-2.515 9.142 0 20.28.578 33.638 1.724 12.65 1.122 23.232 1.713 31.394 1.713 5.906 0 14.504-.579 25.89-1.394 14.362-1.264 26.48-1.972 36.166-1.972 2.244 0 3.366 2.244 3.366 6.756 0 6.035-2.102 9.141-6.154 9.141-14.775 1.524-26.764 5.634-35.764 12.249-9 6.626-20.28 21.673-33.768 45.32l-55.04 100.748 74.044 150.864 109.348-254.306c3.78-9.272 5.634-17.87 5.634-25.618 0-18.556-12.638-28.43-38.138-29.682-2.244 0-3.378-2.657-3.378-7.89 0-5.35 1.677-8.008 5.09-8.008 9.284 0 20.28.58 33.06 1.713 11.8 1.122 21.674 1.724 29.552 1.724 8.456 0 18.012-.578 29.008-1.724 11.374-1.122 21.65-1.713 30.791-1.713 2.847 0 4.24 2.244 4.24 6.756l-.011-.118z')
    ctx.fill(wPath)
    ctx.restore()

    cachedWikiLogo = await canvas.toBuffer('image/jpeg')
    return cachedWikiLogo
}

export default {
    command: true, usePrefix: true,
    case: ['wiki', 'wikipedia'],
    description: 'Busca artículos en Wikipedia con selector dinámico de relacionados.',
    category: 'search',
    usage: ['wiki ‹término›'],
    script: async (m, { sock, scrapers }) => {
        if (!m.text) {
            return m.reply('ⓘ Ingresa el término que deseas buscar en Wikipedia.\n- Ejemplo: .wiki Nikola Tesla\n- Ejemplo: .wiki Videojuego')
        }

        const query = m.text.trim()
        await m.react('wait')

        try {
            const wiki = scrapers.file('search/wikipedia.scraper.js')
            if (!wiki) {
                await m.react('error')
                return m.reply('ⓘ El módulo de Wikipedia no está disponible en scrapers.')
            }

            const res = await wiki.process(query)
            if (!res.status) {
                await m.react('error')
                return m.reply(`ⓘ ${res.msg || 'No se encontraron resultados para tu búsqueda.'}`)
            }

            const buttons = [
                {
                    type: 'url',
                    text: 'Abrir en Wikipedia',
                    url: res.url
                }
            ]

            if (res.related && res.related.length > 0) {
                const rows = res.related.slice(0, 10).map((title, idx) => {
                    const cleanTitle = title.trim()
                    return {
                        title: cleanTitle.length > 24 ? cleanTitle.substring(0, 21) + '...' : cleanTitle,
                        description: `Buscar: ${cleanTitle}`.substring(0, 70),
                        id: `.wiki ${cleanTitle}`
                    }
                })

                buttons.unshift({
                    type: 'list',
                    text: 'Artículos Relacionados',
                    sections: [
                        {
                            title: 'Sugerencias de Wikipedia',
                            rows: rows
                        }
                    ]
                })
            }

            const wikiLogo = await getWikiLogoBuffer()
            const fakeQ = await sock.fakeOrder(m.chat.id, {
                image: wikiLogo,
                orderTitle: `Wikipedia: ${res.title}`.substring(0, 25),
                itemCount: 1,
                message: 'ⓘ Wikipedia: Enciclopedia Libre',
                price: 0,
                currency: 'USD'
            })

            await sock.sendMessage(m.chat.id, {
                mediaMenu: {
                    title: `Wikipedia: ${res.title}`,
                    subtitle: 'La Enciclopedia Libre',
                    body: res.extract,
                    footer: '© 2026 Wikipedia Foundation',
                    buttons: buttons
                }
            }, { quoted: fakeQ })

            await m.react('done')

        } catch (e) {
            console.error('Wikipedia Plugin Error:', e.message)
            await m.react('error')
            return m.reply(`ⓘ Ocurrió un error al buscar en Wikipedia: ${e.message}`)
        }
    }
}